/*
Tout ce qui est écrit ici est entre commentaires.
*/

let compteur=0;


function transferer() {
	let messageActuel = document.getElementById("message");
	messageActuel.innerHTML="Message transféré !";
	document.getElementById("destination").value = document.getElementById("source").value;
	document.getElementById("source").value = "";
}


function afficheMessage() {
	let reponse=prompt("Quel est votre prénom ?");
	if (sessionStorage.getItem('prenom')!=reponse) {
		sessionStorage.setItem('prenom', reponse);
		let sauvegarde = sessionStorage.getItem('prenom');
		document.getElementById("enBas").innerHTML=sauvegarde;
	} else {
		document.getElementById("enBas").innerHTML="Vous vous êtes déjà identifié "+ reponse + " !";
}	
}

let images = document.querySelectorAll('img');
let mySwitch = images[0];
let myLampe = images[1];

// Voici un événement
mySwitch.addEventListener('click', function() {
    let mySrc1 = mySwitch.getAttribute('src');
    if (mySrc1 === 'images/switchOff.png') {
      mySwitch.setAttribute('src', 'images/switchOn.png');
      myLampe.setAttribute('src', 'images/lampeOn.png');
      texte="allumée";
	  compteur+=1;
    } else {
      mySwitch.setAttribute('src', 'images/switchOff.png');
      myLampe.setAttribute('src', 'images/lampeOff.png');
      texte="éteinte";
    }
    document.getElementById("ligne3").innerHTML = "La lampe est "+texte;
	document.getElementById("ligne4").innerHTML = "Vous avez allumé la lampe "+compteur+" fois";
});


// Voici un commentaire
function afficheChoix(){
	let choix=document.getElementsByName('statut');
	let valeur1;
	for(let i = 0; i < choix.length; i++){
		if(choix[i].checked){
			valeur1 = choix[i].value;
			document.getElementById("ligne1").innerHTML = 'Vous êtes '+valeur1;
		}
	}
	let locomotion = document.getElementsByName('ecole');
	let valeur2;
	let nombre=0;
	for(let i = 0; i < locomotion.length; i++){
		if(locomotion[i].checked){
			valeur2 = locomotion[i].value;
			nombre+=1;
		}
	}
	console.log(nombre);
	if (nombre == 1){
		document.getElementById("ligne2").innerHTML = "Vous êtes venu à l'école "+valeur2;
	}
	else{
		document.getElementById("ligne2").innerHTML = "Vous n'avez pas l'air de trop savoir. Il y a "+ nombre +" cases cochées";
	}
}
function changeStyle(){
	document.getElementById("myself").innerHTML = 'Bien joué !';
	let color=document.querySelector("body");
	color.style.backgroundColor="blue";
	document.getElementById("message").innerHTML="La couleur du fond d'écran a changé !";
	let paragraphe=document.querySelectorAll("p");
	paragraphe[1].style.color="red";
	document.getElementById("enBas").innerHTML="Le deuxième paragraphe du document (indice 1) est écrit en rouge !";
}

function auRevoir(){
	document.getElementById("enBas").innerHTML= "Au revoir, j'espère que vous avez appris des choses sur JAVASCRIPT !";
}

function reset(){
	window.location.reload(true);
	sessionStorage.clear();
}
